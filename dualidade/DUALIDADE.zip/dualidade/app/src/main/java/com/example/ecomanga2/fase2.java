package com.example.ecomanga2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class fase2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fase2);
    }
}